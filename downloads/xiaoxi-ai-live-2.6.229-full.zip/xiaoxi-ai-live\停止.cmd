@echo off
chcp 65001 >nul
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0停止.ps1"
ping -n 4 127.0.0.1 >nul
